#ifndef BFIELDANA_h
#define BFIELDANA_h 1

#include "g4root.hh"
//#include "g4xml.hh"

#endif
